import pandas as pd
import numpy as np
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt
from sklearn.linear_model import Lasso, LassoCV
from scipy.stats import norm
from sklearn.preprocessing import PolynomialFeatures
import numpy.linalg as la


def standardize(X):
    """Standardize variables to have mean 0 and std 1"""
    mu = X.mean(axis=0)
    sigma = X.std(axis=0)
    X_tilde = (X - mu)/sigma
    return X_tilde


def BRT(X_tilde, y):
    """Calculate BRT penalty"""
    (N, p) = X_tilde.shape
    sigma = np.std(y, ddof=1)
    c = 1.01
    alpha = 0.05
    penalty_BRT = (sigma*c)/np.sqrt(N)*norm.ppf(1-alpha/(2*p))
    return penalty_BRT


def BCCH(X_tilde, y):
    """Calculate BCCH penalty"""
    (N, p) = X_tilde.shape
    c = 1.01
    alpha = 0.05
    yXscale = (np.max((X_tilde.T ** 2) @ ((y-np.mean(y)) ** 2) / N)) ** 0.5
    penalty_pilot = c / np.sqrt(N) * norm.ppf(1-alpha/(2*p)) * yXscale
    pred = Lasso(alpha=penalty_pilot).fit(X_tilde, y).predict(X_tilde)
    eps = y - pred
    epsXscale = (np.max((X_tilde.T ** 2) @ (eps ** 2) / N)) ** 0.5
    penalty_BCCH = c*norm.ppf(1-alpha/(2*p))*epsXscale/np.sqrt(N)
    return penalty_BCCH


def prepare_data_with_polynomials(dat, zs_common_control, zs_uncommon_control, dummy_vars,
                                  ds=['lgdp_initial'], ys=['gdp_growth']):
    """
    Prepare both original and polynomial-expanded datasets

    Returns:
        dict with keys 'original' and 'poly', each containing processed data
    """
    # Basic setup
    zs = zs_common_control + zs_uncommon_control
    xs = ds + zs
    all_vars = ys + xs

    # Handle missing values for dummy variables
    dat_clean = dat.copy()
    dat_clean[dummy_vars] = dat_clean[dummy_vars].fillna(0)

    # Filter missing data
    I = dat_clean[all_vars].notnull().all(axis=1)
    Z = dat_clean.loc[I, zs].to_numpy()

    # Separate binary and non-binary variables
    binary_mask = np.all(np.isin(Z, [0, 1]), axis=0)
    Z_nonbinary = Z[:, ~binary_mask]
    Z_binary = Z[:, binary_mask]

    zs_arr = np.array(zs)
    zs_nonbinary = zs_arr[~binary_mask].tolist()
    zs_binary = zs_arr[binary_mask].tolist()

    # Create polynomial features
    poly = PolynomialFeatures(degree=2, include_bias=False)
    Z_pol = poly.fit_transform(Z_nonbinary)
    Z_final = np.hstack([Z_pol, Z_binary])
    names_pol = poly.get_feature_names_out(input_features=zs_nonbinary)
    names_zs_poly = np.hstack([names_pol, zs_binary])
    names_xs_poly = np.hstack([ds, names_zs_poly])

    # Extract common variables
    D = dat_clean.loc[I, ds].to_numpy().reshape((-1,))
    y = dat_clean.loc[I, ys].values.reshape((-1,)) * 100

    # Original data
    X_orig = dat_clean.loc[I, xs].to_numpy()
    Z_orig = Z
    X_std_orig = standardize(X_orig)
    Z_std_orig = standardize(Z_orig)
    D_std = standardize(D)

    # Polynomial data
    X_poly = np.column_stack((dat_clean.loc[I, ds].to_numpy(), Z_final))
    X_std_poly = standardize(X_poly)
    Z_std_poly = standardize(Z_final)

    print(f'Z shape: {Z_std_orig.shape}')
    print(f'Z poly shape: {Z_std_poly.shape}')


    return {
        'original': {
            'X_std': X_std_orig,
            'Z_std': Z_std_orig,
            'D_std': D_std,
            'y': y,
            'variable_names': xs,
            'z_names': zs
        },
        'poly': {
            'X_std': X_std_poly,
            'Z_std': Z_std_poly,
            'D_std': D_std,
            'y': y,
            'variable_names': names_xs_poly,
            'z_names': names_zs_poly
        },
        'common': {
            'D': D,
            'y': y,
            'I': I,
            'dat_clean': dat_clean
        }
    }


def fit_lasso_models(X, y, penalty_types=['CV', 'BRT', 'BCCH'], penalty_grid=None, max_iterations=100000):
    """
    Fit Lasso models with multiple penalty types

    Returns:
        dict with penalty values, fitted models, coefficients, and selected variables
    """
    if penalty_grid is None:
        penalty_grid = np.geomspace(start=0.001, stop=100, num=100)

    results = {}

    for penalty_type in penalty_types:
        if penalty_type == 'CV':
            fit = LassoCV(alphas=penalty_grid, cv=5, max_iter=max_iterations).fit(X, y.reshape(-1,))
            penalty = fit.alpha_
        elif penalty_type == 'BRT':
            penalty = BRT(X, y)
            print(f'Computed BRT penalty: {penalty:.4f}')
            fit = Lasso(alpha=penalty, max_iter=max_iterations).fit(X, y.reshape(-1,))
        elif penalty_type == 'BCCH':
            penalty = BCCH(X, y)
            print(f'Computed BCCH penalty: {penalty:.4f}')
            fit = Lasso(alpha=penalty, max_iter=max_iterations).fit(X, y.reshape(-1,))
        else:
            raise ValueError(f"Unknown penalty type: {penalty_type}")

        coefs = fit.coef_
        selected_variables = (coefs != 0)

        results[penalty_type] = {
            'penalty': penalty,
            'fit': fit,
            'coefs': coefs,
            'selected_variables': selected_variables
        }

    return results


def extract_selected_variables(selected_variables, variable_names):
    """Extract and return names of selected variables"""
    return np.array(variable_names)[selected_variables]


def estimate_post_single_lasso(X, D, y, penalty_types=['CV', 'BRT', 'BCCH'], **kwargs):
    """
    Post Single Lasso (PSL) estimation for multiple penalty types
    Note: D should be the original unstandardized D for the final OLS step
    """
    results = {}
    N = X.shape[0]

    lasso_results = fit_lasso_models(X, y, penalty_types, **kwargs)

    for penalty_type in penalty_types:
        selected_vars = lasso_results[penalty_type]['selected_variables']
        Z_J = X[:, selected_vars]

        # OLS on selected variables - use original D (not standardized)
        if Z_J.shape[1] > 0:
            xx = np.column_stack((np.ones(N), D, Z_J))
        else:
            xx = np.column_stack((np.ones(N), D))

        yy = np.array(y).reshape(-1, 1)

        # Use pseudo-inverse to handle rank deficiency - BAD -poly -> rank deficiency 
        try:
            coefs_PSL = np.linalg.inv(xx.T @ xx) @ xx.T @ yy
        except np.linalg.LinAlgError:
            # Handle singular matrix with pseudo-inverse
            coefs_PSL = np.linalg.pinv(xx) @ yy

        alpha_PSL = coefs_PSL[1][0]
        res_PSL = yy - xx @ coefs_PSL

        results[penalty_type] = {
            'alpha': alpha_PSL,
            'residuals': res_PSL.flatten(),
            'selected_vars': selected_vars,
            'penalty': lasso_results[penalty_type]['penalty'],
            'lasso_coefs': lasso_results[penalty_type]['coefs']
        }

    return results


def estimate_post_double_lasso(X, Z, D_orig, y, penalty_types=['CV', 'BRT', 'BCCH'], **kwargs):
    """
    Post Double Lasso (PDL) estimation for multiple penalty types
    Note: D_orig should be the original unstandardized D, Z should be standardized
    """
    results = {}

    for penalty_type in penalty_types:
        # Step 1: Lasso D (original scale) on Z (standardized)
        if penalty_type == 'CV':
            fit_D_Z = LassoCV(alphas=kwargs.get('penalty_grid', np.geomspace(0.001, 100, 100)),
                             cv=5, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, D_orig.reshape(-1,))
        elif penalty_type == 'BRT':
            penalty_D_Z = BRT(Z, D_orig)
            fit_D_Z = Lasso(alpha=penalty_D_Z, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, D_orig.reshape(-1,))
        elif penalty_type == 'BCCH':
            penalty_D_Z = BCCH(Z, D_orig)
            fit_D_Z = Lasso(alpha=penalty_D_Z, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, D_orig.reshape(-1,))

        res_D_Z = D_orig - fit_D_Z.predict(Z)

        # Step 2: Lasso Y on X (standardized, includes D and Z)
        if penalty_type == 'CV':
            fit_Y_X = LassoCV(alphas=kwargs.get('penalty_grid', np.geomspace(0.001, 100, 100)),
                             cv=5, max_iter=kwargs.get('max_iterations', 100000)).fit(X, y.reshape(-1,))
        elif penalty_type == 'BRT':
            penalty_Y_X = BRT(X, y)
            fit_Y_X = Lasso(alpha=penalty_Y_X, max_iter=kwargs.get('max_iterations', 100000)).fit(X, y.reshape(-1,))
        elif penalty_type == 'BCCH':
            penalty_Y_X = BCCH(X, y)
            fit_Y_X = Lasso(alpha=penalty_Y_X, max_iter=kwargs.get('max_iterations', 100000)).fit(X, y.reshape(-1,))

        coefs_Y_X = fit_Y_X.coef_
        res_Y_X = y - fit_Y_X.predict(X).reshape(-1,)

        # Important: Use standardized D coefficient from X regression but apply to standardized D
        D_std = standardize(D_orig.reshape(-1, 1)).flatten()
        res_Y_Z_D = res_Y_X + D_std * coefs_Y_X[0]  # First variable in X is standardized D

        # Calculate alpha
        alpha_PDL = (res_D_Z.T @ res_Y_Z_D) / (res_D_Z.T @ res_D_Z)

        results[penalty_type] = {
            'alpha': alpha_PDL,
            'res_D_Z': res_D_Z,
            'res_Y_Z_D': res_Y_Z_D,
            'selected_vars_D_Z': (fit_D_Z.coef_ != 0),
            'selected_vars_Y_X': (coefs_Y_X != 0)
        }

    return results


def estimate_post_partialling_out_lasso(Z, D_orig, y, penalty_types=['CV', 'BRT', 'BCCH'], **kwargs):
    """
    Post Partialling Out Lasso (PPOL) estimation for multiple penalty types
    Note: D_orig should be the original unstandardized D, Z should be standardized
    """
    results = {}

    for penalty_type in penalty_types:
        # Step 1: Lasso D (original scale) on Z (standardized)
        if penalty_type == 'CV':
            fit_D_Z = LassoCV(alphas=kwargs.get('penalty_grid', np.geomspace(0.001, 100, 100)),
                             cv=5, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, D_orig.reshape(-1,))
        elif penalty_type == 'BRT':
            penalty_D_Z = BRT(Z, D_orig)
            fit_D_Z = Lasso(alpha=penalty_D_Z, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, D_orig.reshape(-1,))
        elif penalty_type == 'BCCH':
            penalty_D_Z = BCCH(Z, D_orig)
            fit_D_Z = Lasso(alpha=penalty_D_Z, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, D_orig.reshape(-1,))

        res_D_Z = D_orig.reshape(-1,) - fit_D_Z.predict(Z)

        # Step 2: Lasso Y on Z (standardized)
        if penalty_type == 'CV':
            fit_Y_Z = LassoCV(alphas=kwargs.get('penalty_grid', np.geomspace(0.001, 100, 100)),
                             cv=5, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, y.reshape(-1,))
        elif penalty_type == 'BRT':
            penalty_Y_Z = BRT(Z, y)
            fit_Y_Z = Lasso(alpha=penalty_Y_Z, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, y.reshape(-1,))
        elif penalty_type == 'BCCH':
            penalty_Y_Z = BCCH(Z, y)
            fit_Y_Z = Lasso(alpha=penalty_Y_Z, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, y.reshape(-1,))

        res_Y_Z = y.reshape(-1,) - fit_Y_Z.predict(Z)

        # Calculate alpha
        alpha_PPOL = (res_D_Z.T @ res_Y_Z) / (res_D_Z.T @ res_D_Z)

        results[penalty_type] = {
            'alpha': alpha_PPOL,
            'res_D_Z': res_D_Z,
            'res_Y_Z': res_Y_Z,
            'selected_vars_D_Z': (fit_D_Z.coef_ != 0),
            'selected_vars_Y_Z': (fit_Y_Z.coef_ != 0)
        }

    return results


def estimate_post_double_selection_lasso(X, Z, D_orig, y, penalty_types=['CV', 'BRT', 'BCCH'], **kwargs):
    """
    Post Double Selection Lasso (PDS) - Belloni et al. (2014) approach
    Step 1: Lasso D on Z (select controls that predict treatment)
    Step 2: Lasso Y on X (select controls that predict outcome)
    Step 3: OLS Y on [D, union(selected_from_step1, selected_from_step2)]
    """
    results = {}
    N = X.shape[0]

    for penalty_type in penalty_types:
        # Step 1: Lasso D (original scale) on Z (standardized) - same as PDL
        if penalty_type == 'CV':
            fit_D_Z = LassoCV(alphas=kwargs.get('penalty_grid', np.geomspace(0.001, 100, 100)),
                             cv=5, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, D_orig.reshape(-1,))
        elif penalty_type == 'BRT':
            penalty_D_Z = BRT(Z, D_orig)
            fit_D_Z = Lasso(alpha=penalty_D_Z, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, D_orig.reshape(-1,))
        elif penalty_type == 'BCCH':
            penalty_D_Z = BCCH(Z, D_orig)
            fit_D_Z = Lasso(alpha=penalty_D_Z, max_iter=kwargs.get('max_iterations', 100000)).fit(Z, D_orig.reshape(-1,))

        selected_vars_D_Z = (fit_D_Z.coef_ != 0)

        # Step 2: Lasso Y on X (standardized, includes D and Z) - same as PDL
        if penalty_type == 'CV':
            fit_Y_X = LassoCV(alphas=kwargs.get('penalty_grid', np.geomspace(0.001, 100, 100)),
                             cv=5, max_iter=kwargs.get('max_iterations', 100000)).fit(X, y.reshape(-1,))
        elif penalty_type == 'BRT':
            penalty_Y_X = BRT(X, y)
            fit_Y_X = Lasso(alpha=penalty_Y_X, max_iter=kwargs.get('max_iterations', 100000)).fit(X, y.reshape(-1,))
        elif penalty_type == 'BCCH':
            penalty_Y_X = BCCH(X, y)
            fit_Y_X = Lasso(alpha=penalty_Y_X, max_iter=kwargs.get('max_iterations', 100000)).fit(X, y.reshape(-1,))

        coefs_Y_X = fit_Y_X.coef_
        selected_vars_Y_X = (coefs_Y_X != 0)

        # Extract Z variables selected in step 2 (exclude first variable which is D)
        selected_vars_Y_Z = selected_vars_Y_X[1:]  # Remove D (first variable)

        # Step 3: Union of selected variables from both steps
        union_selected_Z = selected_vars_D_Z | selected_vars_Y_Z
        Z_union = Z[:, union_selected_Z]

        # OLS on selected variables - always include D plus union of selected Z
        if Z_union.shape[1] > 0:
            xx = np.column_stack((np.ones(N), D_orig, Z_union))
        else:
            xx = np.column_stack((np.ones(N), D_orig))

        yy = np.array(y).reshape(-1, 1)

        # Use pseudo-inverse to "handle" rank deficiency
        try:
            coefs_PDS = np.linalg.inv(xx.T @ xx) @ xx.T @ yy
        except np.linalg.LinAlgError:
            coefs_PDS = np.linalg.pinv(xx) @ yy

        alpha_PDS = coefs_PDS[1][0]
        res_PDS = yy - xx @ coefs_PDS

        results[penalty_type] = {
            'alpha': alpha_PDS,
            'residuals': res_PDS.flatten(),
            'selected_vars_D_Z': selected_vars_D_Z,
            'selected_vars_Y_X': selected_vars_Y_X,
            'selected_vars_Y_Z': selected_vars_Y_Z,
            'union_selected_Z': union_selected_Z,
            'n_selected_stage1': selected_vars_D_Z.sum(),
            'n_selected_stage2': selected_vars_Y_Z.sum(),
            'n_selected_union': union_selected_Z.sum()
        }

    return results


def calculate_variance(res_X, res_Y):
    """Calculate variance for confidence intervals"""
    n = res_X.shape[0]
    num = res_X**2 @ res_Y**2 / n
    denom = (res_X.T @ res_X / n)**2
    sigma2 = num / denom
    return sigma2


def calculate_confidence_intervals(estimates_dict, residuals_dict, alpha=0.05):
    """
    Calculate confidence intervals for multiple estimates

    Parameters:
        estimates_dict: dict with method -> penalty_type -> alpha estimate
        residuals_dict: dict with method -> penalty_type -> (res_D, res_Y) tuple
        alpha: significance level

    Returns:
        dict with confidence intervals
    """
    results = {}
    q = norm.ppf(1 - alpha/2)

    for method in estimates_dict:
        results[method] = {}
        for penalty_type in estimates_dict[method]:
            estimate = estimates_dict[method][penalty_type]

            if method in residuals_dict and penalty_type in residuals_dict[method]:
                res_D, res_Y = residuals_dict[method][penalty_type]
                variance = calculate_variance(res_D, res_Y)
                n = len(res_D)
                se = np.sqrt(variance / n)
                ci_low = estimate - q * se
                ci_high = estimate + q * se

                results[method][penalty_type] = {
                    'estimate': estimate,
                    'se': se,
                    'ci_low': ci_low,
                    'ci_high': ci_high
                }

    return results


def calculate_ols_estimates_with_ci(dat_processed, rounding_digits=12):
    """Calculate OLS estimates with confidence intervals"""
    data_orig = dat_processed['original']
    data_poly = dat_processed['poly']
    common = dat_processed['common']

    D = common['D']
    y = common['y']

    from scipy.stats import norm

    results = {}

    # OLS without controls
    X_no_control = D.reshape(-1, 1)
    X_no_control = np.column_stack((X_no_control, np.ones(X_no_control.shape[0])))
    try:
        beta_hat_no_controls = np.linalg.inv(X_no_control.T @ X_no_control) @ X_no_control.T @ y
    except np.linalg.LinAlgError:
        beta_hat_no_controls = np.linalg.pinv(X_no_control) @ y
    res_OLS_no_controls = y - X_no_control @ beta_hat_no_controls

    # Calculate CI for no controls
    variance_no_controls = calculate_variance(res_OLS_no_controls, res_OLS_no_controls)
    n = len(y)
    se_no_controls = np.sqrt(variance_no_controls / n)
    q = norm.ppf(1 - 0.025)
    ci_low_no_controls = beta_hat_no_controls[0] - q * se_no_controls
    ci_high_no_controls = beta_hat_no_controls[0] + q * se_no_controls

    results['no_controls'] = {
        'estimate': beta_hat_no_controls[0],
        'residuals': res_OLS_no_controls,
        'se': se_no_controls,
        'ci_low': ci_low_no_controls,
        'ci_high': ci_high_no_controls
    }

    # OLS with original controls
    X_with_control = data_orig['X_std']
    X_with_control = np.column_stack((X_with_control, np.ones(X_with_control.shape[0])))
    try:
        beta_hat_w_controls = np.linalg.inv(X_with_control.T @ X_with_control) @ X_with_control.T @ y
    except np.linalg.LinAlgError:
        beta_hat_w_controls = np.linalg.pinv(X_with_control) @ y
    res_OLS_w_controls = y - X_with_control @ beta_hat_w_controls

    # Calculate CI for with controls
    variance_w_controls = calculate_variance(res_OLS_w_controls, res_OLS_w_controls)
    se_w_controls = np.sqrt(variance_w_controls / n)
    ci_low_w_controls = beta_hat_w_controls[0] - q * se_w_controls
    ci_high_w_controls = beta_hat_w_controls[0] + q * se_w_controls

    results['with_controls'] = {
        'estimate': beta_hat_w_controls[0],
        'residuals': res_OLS_w_controls,
        'se': se_w_controls,
        'ci_low': ci_low_w_controls,
        'ci_high': ci_high_w_controls
    }

    # OLS with polynomial controls
    X_with_poly = data_poly['X_std']
    X_with_poly = np.column_stack((X_with_poly, np.ones(X_with_poly.shape[0])))
    try:
        beta_hat_w_poly = np.linalg.inv(X_with_poly.T @ X_with_poly) @ X_with_poly.T @ y
    except np.linalg.LinAlgError:
        beta_hat_w_poly = np.linalg.pinv(X_with_poly) @ y
    res_OLS_w_poly = y - X_with_poly @ beta_hat_w_poly

    # Calculate CI for with poly
    variance_w_poly = calculate_variance(res_OLS_w_poly, res_OLS_w_poly)
    se_w_poly = np.sqrt(variance_w_poly / n)
    ci_low_w_poly = beta_hat_w_poly[0] - q * se_w_poly
    ci_high_w_poly = beta_hat_w_poly[0] + q * se_w_poly

    results['with_poly'] = {
        'estimate': beta_hat_w_poly[0],
        'residuals': res_OLS_w_poly,
        'se': se_w_poly,
        'ci_low': ci_low_w_poly,
        'ci_high': ci_high_w_poly
    }

    return results


def generate_lasso_paths(X, y, penalty_grid=None, max_iterations=100000):
    """Generate coefficient paths for Lasso regularization"""
    if penalty_grid is None:
        penalty_grid = np.geomspace(start=0.001, stop=100, num=100)

    coefs = []
    for penal in penalty_grid:
        fit = Lasso(alpha=penal, max_iter=max_iterations).fit(X, y)
        coefs.append(fit.coef_)

    return penalty_grid, coefs


def plot_lasso_path(penalty_grid, coefs, legends="", title="Lasso Path", vlines=None):
    """
    Plot the coefficients as a function of the penalty parameter for Lasso regression.
    """
    fig, ax = plt.subplots(figsize=(12, 8))  # Larger figure
    ax.plot(penalty_grid, coefs)
    ax.set_xscale('log')
    ax.set_xlim([np.min(penalty_grid), 8])

    plt.xlabel(r'Penalty, $\lambda$')
    plt.ylabel(r'Estimates, $\widehat{\beta}_j(\lambda)$')
    plt.title(title)

    if legends:
        # Determine legend strategy based on number of variables
        n_vars = len(legends)

        if n_vars <= 20:
            # Small number: single column, outside plot
            lgd = ax.legend(legends, loc='center left', bbox_to_anchor=(1.02, 0.5))
            plt.subplots_adjust(right=0.75)
        elif n_vars <= 45:
            # Medium number: two columns, outside plot
            lgd = ax.legend(legends, loc='center left', bbox_to_anchor=(1.02, 0.5), ncol=2)
            plt.subplots_adjust(right=0.65)
        else:
            # Large number: no legend, too crowded
            print(f"Warning: {n_vars} variables - legend omitted to preserve plot readability")
            lgd = None

        if lgd:
            for text in lgd.get_texts():
                text.set_fontsize('small')

    if vlines is not None:
        for name, penalty in vlines.items():
            ax.axvline(x=penalty, linestyle='--', color='grey')
            plt.text(penalty, min(coefs[0]), name, rotation=90)

    # Save as PNG with clean filename
    filename = title.replace(" ", "_").replace(":", "").replace(",", "")
    plt.savefig(f"{filename}.png", dpi=300, bbox_inches='tight')

    plt.show()
    plt.close()


def generate_and_plot_all_lasso_paths(dat_processed, penalty_types=['CV', 'BRT', 'BCCH']):
    """Generate and plot all Lasso paths for both control sets"""

    penalty_grid = np.geomspace(start=0.001, stop=100, num=100)

    for data_type in ['original', 'poly']:
        data = dat_processed[data_type]
        X_std = data['X_std']
        Z_std = data['Z_std']
        D_std = data['D_std']
        y = data['y']
        variable_names = data['variable_names']
        z_names = data['z_names']

        print(f"\n{'='*60}")
        print(f"LASSO PATHS - {data_type.upper()} CONTROLS")
        print(f"{'='*60}")

        # Calculate penalty values
        penalty_CV = LassoCV(cv=5, max_iter=100000).fit(X_std, y).alpha_
        penalty_BRT = BRT(X_std, y)
        penalty_BCCH = BCCH(X_std, y)

        penalty_CV_D = LassoCV(cv=5, max_iter=100000).fit(Z_std, D_std).alpha_
        penalty_BRT_D = BRT(Z_std, D_std)
        penalty_BCCH_D = BCCH(Z_std, D_std)

        vlines_Y = {'CV': penalty_CV, 'BRT': penalty_BRT, 'BCCH': penalty_BCCH}
        vlines_D = {'CV': penalty_CV_D, 'BRT': penalty_BRT_D, 'BCCH': penalty_BCCH_D}

        # Second stage: Y on X (Z and D)
        penalty_grid_Y, coefs_Y = generate_lasso_paths(X_std, y, penalty_grid)

        plot_lasso_path(
            penalty_grid=penalty_grid_Y,
            coefs=coefs_Y,
            title=f"Second Stage: Y on X - {data_type.title()} Controls",
            vlines=vlines_Y,
            legends=variable_names if data_type == 'original' else None
        )

        # First stage: D on Z
        penalty_grid_D, coefs_D = generate_lasso_paths(Z_std, D_std, penalty_grid)

        plot_lasso_path(
            penalty_grid=penalty_grid_D,
            coefs=coefs_D,
            title=f"First Stage: D on Z - {data_type.title()} Controls",
            vlines=vlines_D,
            legends=z_names if data_type == 'original' else None
        )


def print_variable_selection(results_dict, variable_names, z_names, data_type="Original"):
    """Print selected variables for all methods and penalty types"""

    print(f"\n{'='*80}")
    print(f"VARIABLE SELECTION - {data_type.upper()} CONTROLS")
    print(f"{'='*80}")

    methods = [
        ('PSL', results_dict['psl'], variable_names),
        ('PDL_Stage1', results_dict['pdl'], z_names, 'selected_vars_D_Z'),
        ('PDL_Stage2', results_dict['pdl'], variable_names, 'selected_vars_Y_X'),
        ('PPOL_Stage1', results_dict['ppol'], z_names, 'selected_vars_D_Z'),
        ('PPOL_Stage2', results_dict['ppol'], z_names, 'selected_vars_Y_Z'),
        ('PDS_Stage1', results_dict['pds'], z_names, 'selected_vars_D_Z'),
        ('PDS_Stage2', results_dict['pds'], z_names, 'selected_vars_Y_Z'),
        ('PDS_Union', results_dict['pds'], z_names, 'union_selected_Z')
    ]

    for method_info in methods:
        method_name = method_info[0]
        method_results = method_info[1]
        var_names = method_info[2]
        var_key = method_info[3] if len(method_info) > 3 else 'selected_vars'

        print(f"\n{method_name} - Selected Variables:")
        for penalty_type in ['CV', 'BRT', 'BCCH']:
            if penalty_type in method_results:
                if var_key in method_results[penalty_type]:
                    selected = method_results[penalty_type][var_key]
                else:
                    selected = method_results[penalty_type]['selected_vars']
                selected_vars = extract_selected_variables(selected, var_names)
                print(f"  {penalty_type}: {list(selected_vars)}")


def print_results_summary(ols_results, psl_results, pdl_results, ppol_results, pds_results,
                         ci_results, data_type="Original", rounding_digits=12):
    """Print a comprehensive summary of all results"""

    print(f"\n{'='*60}")
    print(f"RESULTS SUMMARY - {data_type.upper()} CONTROLS")
    print(f"{'='*60}")

    # OLS Results
    print(f"\nOLS ESTIMATES:")
    print(f"{'Method':<25} {'Estimate':<15} {'SE':<10} {'CI Lower':<12} {'CI Upper':<12}")
    print(f"{'-'*80}")
    for method, result in ols_results.items():
        if 'se' in result:
            print(f"{method.replace('_', ' ').title():<25} {result['estimate']:<15.4f} {result['se']:<10.4f} {result['ci_low']:<12.4f} {result['ci_high']:<12.4f}")
        else:
            print(f"{method.replace('_', ' ').title():<25} {result['estimate']:<15.4f} {'N/A':<10} {'N/A':<12} {'N/A':<12}")

    # Post-LASSO Results
    methods = [
        ('PSL', psl_results),
        ('PDL', pdl_results),
        ('PPOL', ppol_results),
        ('PDS', pds_results)
    ]

    for method_name, results in methods:
        print(f"\n{method_name} ESTIMATES:")
        print(f"{'Penalty':<10} {'Estimate':<15} {'SE':<10} {'CI Lower':<12} {'CI Upper':<12}")
        print(f"{'-'*65}")

        for penalty_type in ['CV', 'BRT', 'BCCH']:
            if penalty_type in results:
                estimate = results[penalty_type]['alpha']

                if method_name in ci_results and penalty_type in ci_results[method_name]:
                    ci_data = ci_results[method_name][penalty_type]
                    se = ci_data['se']
                    ci_low = ci_data['ci_low']
                    ci_high = ci_data['ci_high']
                    print(f"{penalty_type:<10} {estimate:<15.4f} {se:<10.4f} {ci_low:<12.4f} {ci_high:<12.4f}")
                else:
                    print(f"{penalty_type:<10} {estimate:<15.4f} {'N/A':<10} {'N/A':<12} {'N/A':<12}")


def run_complete_analysis(dat, zs_common_control, zs_uncommon_control, dummy_vars,
                         penalty_types=['CV', 'BRT', 'BCCH'], rounding_digits=4):
    """
    Run the complete analysis for both original and polynomial controls
    """
    print("Preparing data...")
    dat_processed = prepare_data_with_polynomials(dat, zs_common_control, zs_uncommon_control, dummy_vars)

    # Common parameters
    penalty_grid = np.geomspace(start=0.001, stop=100, num=100)
    max_iterations = 100000
    kwargs = {'penalty_grid': penalty_grid, 'max_iterations': max_iterations}

    results = {}

    for data_type in ['original', 'poly']:
        print(f"\nAnalyzing {data_type} controls...")

        data = dat_processed[data_type]
        X_std = data['X_std']
        Z_std = data['Z_std']
        D_std = data['D_std']
        y = data['y']
        variable_names = data['variable_names']
        z_names = data['z_names']

        # OLS estimates with confidence intervals
        ols_results = calculate_ols_estimates_with_ci(dat_processed)

        # Post-LASSO estimates - pass original D for all methods (not standardized)
        D_orig = dat_processed['common']['D']
        psl_results = estimate_post_single_lasso(X_std, D_orig, y, penalty_types, **kwargs)
        pdl_results = estimate_post_double_lasso(X_std, Z_std, D_orig, y, penalty_types, **kwargs)
        ppol_results = estimate_post_partialling_out_lasso(Z_std, D_orig, y, penalty_types, **kwargs)
        pds_results = estimate_post_double_selection_lasso(X_std, Z_std, D_orig, y, penalty_types, **kwargs)

        # Prepare residuals for CI calculation
        residuals_dict = {
            'PSL': {pt: (np.ones_like(psl_results[pt]['residuals']), psl_results[pt]['residuals'])
                    for pt in penalty_types if pt in psl_results},
            'PDL': {pt: (pdl_results[pt]['res_D_Z'], pdl_results[pt]['res_Y_Z_D'])
                    for pt in penalty_types if pt in pdl_results},
            'PPOL': {pt: (ppol_results[pt]['res_D_Z'], ppol_results[pt]['res_Y_Z'])
                     for pt in penalty_types if pt in ppol_results},
            'PDS': {pt: (np.ones_like(pds_results[pt]['residuals']), pds_results[pt]['residuals'])
                    for pt in penalty_types if pt in pds_results}
        }

        estimates_dict = {
            'PSL': {pt: psl_results[pt]['alpha'] for pt in penalty_types if pt in psl_results},
            'PDL': {pt: pdl_results[pt]['alpha'] for pt in penalty_types if pt in pdl_results},
            'PPOL': {pt: ppol_results[pt]['alpha'] for pt in penalty_types if pt in ppol_results},
            'PDS': {pt: pds_results[pt]['alpha'] for pt in penalty_types if pt in pds_results}
        }

        # Calculate confidence intervals
        ci_results = calculate_confidence_intervals(estimates_dict, residuals_dict)

        # Print results
        print_results_summary(ols_results, psl_results, pdl_results, ppol_results, pds_results,
                            ci_results, data_type.capitalize(), rounding_digits)

        # Print variable selection
        results_dict = {'psl': psl_results, 'pdl': pdl_results, 'ppol': ppol_results, 'pds': pds_results}
        print_variable_selection(results_dict, variable_names, z_names, data_type.capitalize())

        # Store results for return
        results[data_type] = {
            'ols': ols_results,
            'psl': psl_results,
            'pdl': pdl_results,
            'ppol': ppol_results,
            'pds': pds_results,
            'ci': ci_results,
            'data': data
        }

    return results, dat_processed